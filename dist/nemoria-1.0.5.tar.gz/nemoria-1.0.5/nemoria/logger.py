import logging


logger = logging.getLogger("nemoria")
logging.basicConfig(level=logging.INFO, format="%(message)s")

# "%(levelname)s: %(message)s"
